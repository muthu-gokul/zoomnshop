package com.example.zoomnshop;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
